// ===== teacher.js - 교사 로그인, 문제 관리, 게임 대시보드 =====

let currentGameCode = null;
let currentTeacherCode = null;
let gameTimerInterval = null;
let stageCount = 0;
let questionIdCounter = 0;

// ---- Teacher Login/Register ----
function switchLoginTab(tab) {
    document.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
    document.getElementById('tab-existing').classList.add('hidden');
    document.getElementById('tab-new').classList.add('hidden');
    document.getElementById('teacher-code-result').classList.add('hidden');
    if (tab === 'existing') {
        document.getElementById('tab-existing').classList.remove('hidden');
        document.querySelectorAll('.tab-btn')[0].classList.add('active');
    } else {
        document.getElementById('tab-new').classList.remove('hidden');
        document.querySelectorAll('.tab-btn')[1].classList.add('active');
    }
}

async function teacherLogin() {
    const code = document.getElementById('teacher-code-input').value.trim().toUpperCase();
    if (code.length < 4) { showToast('교사 코드를 입력해주세요'); return; }
    const teacher = await getTeacher(code);
    if (!teacher) { showToast('등록되지 않은 코드입니다'); return; }
    currentTeacherCode = code;
    localStorage.setItem('teacherCode', code);
    document.getElementById('teacher-home-title').textContent = `👩‍🏫 ${teacher.name} 선생님`;
    document.getElementById('teacher-badge').textContent = code;
    showPage('page-teacher-home');
    addStage(); addStage();
}

async function teacherRegister() {
    const name = document.getElementById('teacher-name-input').value.trim();
    if (!name) { showToast('이름을 입력해주세요'); return; }
    const school = document.getElementById('teacher-school-input').value.trim();
    const code = generateTeacherCode();
    await saveTeacher(code, { name, school, createdAt: Date.now(), questionSets: {} });
    currentTeacherCode = code;
    localStorage.setItem('teacherCode', code);

    document.getElementById('tab-new').classList.add('hidden');
    document.getElementById('teacher-code-result').classList.remove('hidden');
    document.getElementById('my-teacher-code').textContent = code;
}

function goToTeacherHome() {
    showPage('page-teacher-home');
    document.getElementById('teacher-badge').textContent = currentTeacherCode;
    addStage(); addStage();
}

// ---- Home Tabs ----
function switchHomeTab(tab) {
    document.querySelectorAll('.home-tab').forEach(b => b.classList.remove('active'));
    document.querySelectorAll('.home-content').forEach(c => c.classList.add('hidden'));
    document.getElementById('home-tab-' + tab).classList.add('active');
    document.getElementById('home-content-' + tab).classList.remove('hidden');
    if (tab === 'library') loadLibrary();
    if (tab === 'mysets') loadMySets();
}

// ---- Stage & Question Management ----
function addStage() {
    stageCount++;
    const stageId = stageCount;
    const container = document.getElementById('stages-container');
    const card = document.createElement('div');
    card.className = 'stage-card';
    card.id = `stage-${stageId}`;
    card.innerHTML = `
        <div class="stage-card-header">
            <h4>🏁 스테이지 ${stageId}</h4>
            <button class="btn-remove-stage" onclick="removeStage(${stageId})">✕</button>
        </div>
        <div id="questions-${stageId}" class="questions-list"></div>
        <button class="btn-add-question" onclick="addQuestion(${stageId})">+ 문제 추가</button>
    `;
    container.appendChild(card);
    addQuestion(stageId);
}

function removeStage(stageId) {
    const el = document.getElementById(`stage-${stageId}`);
    if (el) el.remove();
    renumberStages();
}

function renumberStages() {
    document.querySelectorAll('.stage-card').forEach((card, i) => {
        card.querySelector('h4').textContent = `🏁 스테이지 ${i + 1}`;
    });
}

function addQuestion(stageId) {
    questionIdCounter++;
    const qId = questionIdCounter;
    const container = document.getElementById(`questions-${stageId}`);
    const item = document.createElement('div');
    item.className = 'question-item';
    item.id = `q-${qId}`;
    item.innerHTML = `
        <button class="btn-remove-q" onclick="this.parentElement.remove()">✕</button>
        <div class="form-group">
            <label>문제 유형</label>
            <select onchange="toggleQuestionType(${qId}, this.value)" id="qtype-${qId}">
                <option value="multiple">객관식 (4지선다)</option>
                <option value="short">주관식 (단답형)</option>
            </select>
        </div>
        <div class="form-group">
            <label>문제</label>
            <input type="text" id="qtext-${qId}" placeholder="문제를 입력하세요">
        </div>
        <div id="qchoices-${qId}">
            <div class="form-group">
                <label>보기</label>
                <div class="choices-edit">
                    <input type="text" id="qc-${qId}-0" placeholder="① 보기1">
                    <input type="text" id="qc-${qId}-1" placeholder="② 보기2">
                    <input type="text" id="qc-${qId}-2" placeholder="③ 보기3">
                    <input type="text" id="qc-${qId}-3" placeholder="④ 보기4">
                </div>
            </div>
            <div class="correct-marker">
                <label>정답:</label>
                <select id="qans-m-${qId}">
                    <option value="0">①</option><option value="1">②</option>
                    <option value="2">③</option><option value="3">④</option>
                </select>
            </div>
        </div>
        <div id="qshort-${qId}" class="hidden">
            <div class="form-group">
                <label>정답 (쉼표로 복수 정답 구분)</label>
                <input type="text" id="qans-s-${qId}" placeholder="정답1, 정답2">
            </div>
        </div>
    `;
    container.appendChild(item);
}

function toggleQuestionType(qId, type) {
    const choices = document.getElementById(`qchoices-${qId}`);
    const short = document.getElementById(`qshort-${qId}`);
    if (type === 'multiple') { choices.classList.remove('hidden'); short.classList.add('hidden'); }
    else { choices.classList.add('hidden'); short.classList.remove('hidden'); }
}

// ---- Collect Stages Data ----
function collectStages() {
    const stageCards = document.querySelectorAll('.stage-card');
    if (stageCards.length < 2) { showToast('스테이지를 최소 2개 이상 만들어주세요!'); return null; }
    const stages = [];
    let valid = true;
    stageCards.forEach(card => {
        const questions = [];
        card.querySelectorAll('.question-item').forEach(qItem => {
            const qId = qItem.id.replace('q-', '');
            const type = document.getElementById(`qtype-${qId}`).value;
            const text = document.getElementById(`qtext-${qId}`).value.trim();
            if (!text) { valid = false; return; }
            if (type === 'multiple') {
                const choices = [];
                for (let i = 0; i < 4; i++) {
                    const c = document.getElementById(`qc-${qId}-${i}`).value.trim();
                    if (!c) { valid = false; return; }
                    choices.push(c);
                }
                questions.push({ type: 'multiple', text, choices, answer: parseInt(document.getElementById(`qans-m-${qId}`).value) });
            } else {
                const answerRaw = document.getElementById(`qans-s-${qId}`).value.trim();
                if (!answerRaw) { valid = false; return; }
                questions.push({ type: 'short', text, answers: answerRaw.split(',').map(a => a.trim().toLowerCase()).filter(a => a) });
            }
        });
        if (questions.length === 0) valid = false;
        stages.push(questions);
    });
    if (!valid) { showToast('모든 문제와 보기를 빠짐없이 입력해주세요!'); return null; }
    return stages;
}

// ---- Create Game ----
function createGame() {
    const stages = collectStages();
    if (!stages) return;
    const title = document.getElementById('game-title').value.trim() || '고고전진!';
    const timer = parseInt(document.getElementById('game-timer').value) || 10;
    const teamMode = document.getElementById('team-mode').checked;
    const code = generateCode();
    const gameData = {
        code, title, timer: timer * 60, teamMode, stages,
        players: {}, status: 'waiting', startedAt: null,
        createdAt: Date.now(), teacherCode: currentTeacherCode || ''
    };
    saveGame(code, gameData);
    currentGameCode = code;
    document.getElementById('dash-game-code').textContent = code;
    document.getElementById('game-code-big').textContent = code;
    if (teamMode) document.getElementById('team-scores').classList.remove('hidden');
    showPage('page-teacher-dashboard');
    startDashboardPolling();
}

// ---- Dashboard ----
function startDashboardPolling() {
    if (currentGameCode && dbReady) {
        listenGame(currentGameCode, (game) => { renderDashboard(game); });
    }
}

function renderDashboard(game) {
    if (!game) return;
    const players = Object.values(game.players || {});
    const totalStages = game.stages.length;
    document.getElementById('dash-players').textContent = players.length + '명';

    const grid = document.getElementById('players-grid');
    grid.innerHTML = '';
    players.forEach(p => {
        const cleared = p.currentStage > totalStages;
        let cls = 'player-card' + (cleared ? ' cleared' : '');
        if (game.teamMode && p.team === 'A') cls += ' team-a-card';
        if (game.teamMode && p.team === 'B') cls += ' team-b-card';
        const card = document.createElement('div');
        card.className = cls;
        card.innerHTML = `<div class="player-name">${escapeHtml(p.name)}</div>
            <div class="player-stage ${cleared ? 'cleared' : ''}">${cleared ? '🏆 클리어!' : `스테이지 ${p.currentStage}/${totalStages}`}</div>`;
        grid.appendChild(card);
    });

    if (game.teamMode) {
        let aScore = 0, bScore = 0;
        players.forEach(p => { const s = Math.min(p.currentStage - 1, totalStages); if (p.team === 'A') aScore += s; else bScore += s; });
        document.getElementById('team-a-score').textContent = aScore;
        document.getElementById('team-b-score').textContent = bScore;
    }

    if (game.status === 'playing' && game.startedAt) {
        const remaining = Math.max(0, game.timer - Math.floor((Date.now() - game.startedAt) / 1000));
        const m = Math.floor(remaining / 60), s = remaining % 60;
        document.getElementById('dash-timer').textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
        if (remaining <= 0) endGame();
    }
}

function startGame() {
    if (!currentGameCode) return;
    getGameAsync(currentGameCode).then(game => {
        if (!game) return;
        if (Object.keys(game.players || {}).length === 0) { showToast('참여한 학생이 없습니다!'); return; }
        updateGameField(currentGameCode, 'status', 'playing');
        updateGameField(currentGameCode, 'startedAt', Date.now());
        document.getElementById('share-area').classList.add('hidden');
        document.getElementById('game-progress').classList.remove('hidden');
        document.getElementById('btn-end-game').classList.remove('hidden');
    });
}

function endGame() {
    if (!currentGameCode) return;
    updateGameField(currentGameCode, 'status', 'finished');
    getGameAsync(currentGameCode).then(game => { if (game) showResults(game); });
}

function showResults(game) {
    const players = Object.values(game.players || {});
    const totalStages = game.stages.length;
    document.getElementById('game-progress').classList.add('hidden');
    document.getElementById('btn-end-game').classList.add('hidden');
    document.getElementById('game-results').classList.remove('hidden');
    let html = '';
    if (game.teamMode) {
        let aS=0,bS=0,aC=0,bC=0;
        players.forEach(p => { const c=p.currentStage>totalStages; if(p.team==='A'){aS+=Math.min(p.currentStage-1,totalStages);if(c)aC++;}else{bS+=Math.min(p.currentStage-1,totalStages);if(c)bC++;} });
        const w = aS>bS?'A팀 승리! 🎉':aS<bS?'B팀 승리! 🎉':'무승부! 🤝';
        html += `<div style="text-align:center;font-size:28px;font-weight:800;margin-bottom:20px;color:#ffd700">${w}</div>`;
    }
    const sorted = [...players].sort((a,b)=>b.currentStage-a.currentStage||(a.clearedAt||Infinity)-(b.clearedAt||Infinity));
    html += `<table class="results-table"><thead><tr><th>순위</th><th>이름</th>${game.teamMode?'<th>팀</th>':''}<th>진행</th><th>오답</th></tr></thead><tbody>`;
    sorted.forEach((p,i) => {
        const c = p.currentStage > totalStages;
        html += `<tr${c?' class="result-winner"':''}><td>${i+1}</td><td>${escapeHtml(p.name)}</td>${game.teamMode?`<td>${p.team==='A'?'🔴':'🔵'}</td>`:''}<td>${c?'🏆':''+Math.max(0,p.currentStage-1)+'/'+totalStages}</td><td>${p.wrongCount||0}</td></tr>`;
    });
    html += '</tbody></table>';
    document.getElementById('results-content').innerHTML = html;
}

function confirmLeave() {
    if (currentGameCode && confirm('게임을 종료하고 나가시겠습니까?')) {
        updateGameField(currentGameCode, 'status', 'finished');
        currentGameCode = null;
    }
    showPage('page-teacher-home');
}

function copyGameCode() {
    if (!currentGameCode) return;
    navigator.clipboard.writeText(currentGameCode).then(() => showToast('게임 코드 복사됨!')).catch(() => showToast(currentGameCode));
}

function escapeHtml(t) { const d=document.createElement('div'); d.textContent=t; return d.innerHTML; }
function escapeAttr(t) { return t.replace(/"/g,'&quot;').replace(/'/g,'&#39;').replace(/</g,'&lt;').replace(/>/g,'&gt;'); }
