// ===== teacher-library.js - 문제 라이브러리 & 붙여넣기 파서 =====

// ---- Question Library (Shared) ----
async function loadLibrary() {
    const list = document.getElementById('library-list');
    list.innerHTML = '<div class="loading-msg">불러오는 중...</div>';
    try {
        const sets = await getQuestionSets();
        if (sets.length === 0) {
            list.innerHTML = '<div class="empty-msg">아직 공유된 문제 세트가 없습니다.<br>첫 번째로 공유해보세요! 📚</div>';
            return;
        }
        list.innerHTML = '';
        sets.forEach(s => {
            const totalQ = (s.stages || []).reduce((sum, st) => sum + st.length, 0);
            const card = document.createElement('div');
            card.className = 'library-card';
            card.innerHTML = `
                <div class="lib-card-top">
                    <span class="lib-badge">${s.grade || '?'}학년 ${s.subject || ''}</span>
                    <span class="lib-use-count">📥 ${s.useCount || 0}회 사용</span>
                </div>
                <h4 class="lib-title">${escapeHtml(s.title || '제목 없음')}</h4>
                <p class="lib-info">${(s.stages || []).length}단계 · ${totalQ}문제 · ${s.teacherName || '익명'} 선생님</p>
                <div class="lib-actions">
                    <button class="btn-lib-use" onclick="useQuestionSet('${s.id}')">📥 가져오기</button>
                </div>
            `;
            list.appendChild(card);
        });
    } catch(e) {
        list.innerHTML = '<div class="empty-msg">불러오기 실패. 인터넷 연결을 확인해주세요.</div>';
    }
}

async function loadMySets() {
    const list = document.getElementById('mysets-list');
    if (!currentTeacherCode) { list.innerHTML = '<div class="empty-msg">로그인이 필요합니다.</div>'; return; }
    list.innerHTML = '<div class="loading-msg">불러오는 중...</div>';
    try {
        const sets = await getQuestionSets();
        const mySets = sets.filter(s => s.teacherCode === currentTeacherCode);
        if (mySets.length === 0) {
            list.innerHTML = '<div class="empty-msg">저장된 문제 세트가 없습니다.<br>게임 만들기에서 💾 저장 버튼을 눌러보세요!</div>';
            return;
        }
        list.innerHTML = '';
        mySets.forEach(s => {
            const totalQ = (s.stages||[]).reduce((sum,st)=>sum+st.length,0);
            const card = document.createElement('div');
            card.className = 'library-card';
            card.innerHTML = `
                <div class="lib-card-top">
                    <span class="lib-badge">${s.grade||'?'}학년 ${s.subject||''}</span>
                    <span class="lib-use-count">${s.isPublic ? '🌐 공유중' : '🔒 비공개'}</span>
                </div>
                <h4 class="lib-title">${escapeHtml(s.title||'제목 없음')}</h4>
                <p class="lib-info">${(s.stages||[]).length}단계 · ${totalQ}문제</p>
                <div class="lib-actions">
                    <button class="btn-lib-use" onclick="useQuestionSet('${s.id}')">📥 게임에 적용</button>
                </div>`;
            list.appendChild(card);
        });
    } catch(e) {
        list.innerHTML = '<div class="empty-msg">불러오기 실패.</div>';
    }
}

async function useQuestionSet(setId) {
    const set = await getQuestionSet(setId);
    if (!set || !set.stages) { showToast('문제 세트를 불러올 수 없습니다'); return; }
    await incrementUseCount(setId);
    // Load into game creator
    document.getElementById('stages-container').innerHTML = '';
    stageCount = 0; questionIdCounter = 0;
    set.stages.forEach((questions, idx) => {
        stageCount++;
        const stageId = stageCount;
        const container = document.getElementById('stages-container');
        const card = document.createElement('div');
        card.className = 'stage-card'; card.id = `stage-${stageId}`;
        card.innerHTML = `<div class="stage-card-header"><h4>🏁 스테이지 ${idx+1}</h4><button class="btn-remove-stage" onclick="removeStage(${stageId})">✕</button></div><div id="questions-${stageId}" class="questions-list"></div><button class="btn-add-question" onclick="addQuestion(${stageId})">+ 문제 추가</button>`;
        container.appendChild(card);
        questions.forEach(q => fillQuestion(stageId, q));
    });
    switchHomeTab('create');
    document.getElementById('game-title').value = set.title || '';
    showToast(`✅ "${set.title}" 문제 세트를 불러왔습니다!`);
}

function fillQuestion(stageId, q) {
    questionIdCounter++;
    const qId = questionIdCounter;
    const qContainer = document.getElementById(`questions-${stageId}`);
    const item = document.createElement('div');
    item.className = 'question-item'; item.id = `q-${qId}`;
    const isShort = q.type === 'short';
    item.innerHTML = `
        <button class="btn-remove-q" onclick="this.parentElement.remove()">✕</button>
        <div class="form-group"><label>문제 유형</label>
            <select onchange="toggleQuestionType(${qId}, this.value)" id="qtype-${qId}">
                <option value="multiple" ${!isShort?'selected':''}>객관식</option>
                <option value="short" ${isShort?'selected':''}>주관식</option>
            </select></div>
        <div class="form-group"><label>문제</label><input type="text" id="qtext-${qId}" value="${escapeAttr(q.text||'')}"></div>
        <div id="qchoices-${qId}" ${isShort?'class="hidden"':''}>
            <div class="form-group"><label>보기</label><div class="choices-edit">
                <input type="text" id="qc-${qId}-0" value="${escapeAttr((q.choices||[])[0]||'')}">
                <input type="text" id="qc-${qId}-1" value="${escapeAttr((q.choices||[])[1]||'')}">
                <input type="text" id="qc-${qId}-2" value="${escapeAttr((q.choices||[])[2]||'')}">
                <input type="text" id="qc-${qId}-3" value="${escapeAttr((q.choices||[])[3]||'')}">
            </div></div>
            <div class="correct-marker"><label>정답:</label><select id="qans-m-${qId}">
                <option value="0" ${q.answer===0?'selected':''}>①</option><option value="1" ${q.answer===1?'selected':''}>②</option>
                <option value="2" ${q.answer===2?'selected':''}>③</option><option value="3" ${q.answer===3?'selected':''}>④</option>
            </select></div></div>
        <div id="qshort-${qId}" ${!isShort?'class="hidden"':''}>
            <div class="form-group"><label>정답</label><input type="text" id="qans-s-${qId}" value="${escapeAttr((q.answers||[]).join(', '))}"></div></div>`;
    qContainer.appendChild(item);
}

// ---- Save Question Set ----
function saveAsQuestionSet() {
    const stages = collectStages();
    if (!stages) return;
    document.getElementById('save-set-modal').classList.remove('hidden');
    document.getElementById('set-title').value = document.getElementById('game-title').value || '';
}
function closeSaveSetModal() { document.getElementById('save-set-modal').classList.add('hidden'); }

async function confirmSaveQuestionSet() {
    const stages = collectStages();
    if (!stages) return;
    const title = document.getElementById('set-title').value.trim() || '제목 없음';
    const grade = document.getElementById('set-grade').value;
    const subject = document.getElementById('set-subject').value;
    const isPublic = document.getElementById('set-public').checked;
    const teacher = currentTeacherCode ? await getTeacher(currentTeacherCode) : null;
    const data = {
        title, grade, subject, isPublic, stages,
        teacherCode: currentTeacherCode || '',
        teacherName: teacher ? teacher.name : '익명',
        useCount: 0
    };
    await saveQuestionSet(data);
    closeSaveSetModal();
    showToast(`✅ "${title}" 저장 완료! ${isPublic ? '다른 선생님도 사용 가능합니다.' : ''}`);
}

// ---- Paste Import ----
let parsedStages = null;

function openPasteModal() {
    document.getElementById('paste-modal').classList.remove('hidden');
    document.getElementById('paste-textarea').value = '';
    document.getElementById('paste-preview').classList.add('hidden');
    document.getElementById('btn-apply-paste').disabled = true;
    parsedStages = null;
    const ta = document.getElementById('paste-textarea');
    ta.removeEventListener('input', onPasteInput);
    ta.addEventListener('input', onPasteInput);
    ta.focus();
}
function closePasteModal() { document.getElementById('paste-modal').classList.add('hidden'); }

function onPasteInput() {
    const text = document.getElementById('paste-textarea').value;
    if (text.trim().length < 5) { document.getElementById('paste-preview').classList.add('hidden'); document.getElementById('btn-apply-paste').disabled = true; parsedStages = null; return; }
    parsedStages = parseHwpText(text);
    showParsePreview(parsedStages);
}

function parseHwpText(rawText) {
    const lines = rawText.split('\n').map(l => l.trim()).filter(l => l.length > 0);
    const stagePattern = /^[<＜〈【]?\s*(\d+)\s*단계\s*[>＞〉】]?\s*(.*)/;
    const skipPattern = /^(고고전진|퀴즈|^\d+학년|^번$)/;
    const hasTabLines = lines.filter(l => l.includes('\t')).length;
    if (hasTabLines / lines.length > 0.3) return parseTabFormat(lines, stagePattern, skipPattern);
    return parseAlternatingFormat(lines, stagePattern, skipPattern);
}

function parseTabFormat(lines, sp, skip) {
    const stages = []; let cur = null;
    for (let line of lines) {
        let m = line.match(sp);
        if (m) { cur = { title: m[2].replace(/^[:\s]+/,'').trim() || `스테이지 ${stages.length+1}`, questions: [] }; stages.push(cur); continue; }
        if (!cur) { if (skip.test(line) || (line.length<50 && !line.includes('\t'))) continue; cur = { title:'스테이지 1', questions:[] }; stages.push(cur); }
        let p = line.split('\t').map(x=>x.trim()).filter(x=>x);
        if (p.length >= 2 && p[0].length >= 3 && p[0] !== p[p.length-1]) {
            cur.questions.push({ text: p[0].replace(/^[\s·•\-]+/,'').trim(), answer: p[p.length-1].replace(/^정답\s*[:：]\s*/i,'').trim() });
        } else if (p.length===1 && p[0].match(/[?？]$/) && p[0].length>=5) {
            cur.questions.push({ text: p[0].trim(), answer: '' });
        }
    }
    return stages.filter(s => s.questions.length > 0);
}

function parseAlternatingFormat(lines, sp, skip) {
    const stages = []; const cl = [];
    for (let line of lines) {
        let m = line.match(sp);
        if (m) { cl.push({ type:'stage', stageTitle: m[2].replace(/^[:\s]+/,'').trim() || `스테이지 ${cl.filter(c=>c.type==='stage').length+1}` }); continue; }
        if (skip.test(line) || line.length < 2) continue;
        cl.push({ type:'content', text: line });
    }
    const co = cl.filter(c=>c.type==='content');
    let score = 0;
    for (let i=0; i<co.length-1; i+=2) {
        const f=co[i].text, s=co[i+1]?co[i+1].text:'';
        if ((f.length>s.length&&s.length>0)||f.match(/[?？]$/)||f.length>15) score++;
    }
    const alt = co.length>2 && score>=co.length/4;
    let cur = null;
    for (let item of cl) {
        if (item.type==='stage') { cur = { title:item.stageTitle, questions:[] }; stages.push(cur); continue; }
        if (!cur) { cur = { title:'스테이지 1', questions:[] }; stages.push(cur); }
        if (alt) {
            const ni = cl.indexOf(item)+1;
            let ans = '';
            if (ni<cl.length && cl[ni].type==='content') {
                const nt = cl[ni].text;
                if (nt.length < item.text.length || !nt.match(/[?？]$/)) { ans = nt; cl[ni].type = 'consumed'; }
            }
            if (item.type==='consumed') continue;
            cur.questions.push({ text: item.text.trim(), answer: ans.trim() });
        } else {
            if (item.text.length<5) continue;
            cur.questions.push({ text: item.text.trim(), answer: '' });
        }
    }
    return stages.filter(s => s.questions.length > 0);
}

function showParsePreview(stages) {
    const preview = document.getElementById('paste-preview');
    const content = document.getElementById('paste-preview-content');
    if (!stages || stages.length===0) { content.innerHTML = '<p style="color:#ff006e">문제를 인식하지 못했습니다.</p>'; preview.classList.remove('hidden'); document.getElementById('btn-apply-paste').disabled = true; return; }
    let totalQ = 0, html = '';
    stages.forEach((s,i) => {
        totalQ += s.questions.length;
        html += `<div class="preview-stage"><div class="preview-stage-title">🏁 스테이지 ${i+1}: ${escapeHtml(s.title)} <span class="preview-count">${s.questions.length}문제</span></div>`;
        s.questions.forEach(q => html += `<div class="preview-question"><span class="preview-q">${escapeHtml(q.text)}</span><span class="preview-a">${q.answer?escapeHtml(q.answer):'<em style="color:#ff006e">정답 없음</em>'}</span></div>`);
        html += '</div>';
    });
    content.innerHTML = `<p style="margin-bottom:12px;color:#00d4ff">✅ ${stages.length}개 스테이지, 총 ${totalQ}개 문제 인식</p>` + html;
    preview.classList.remove('hidden');
    document.getElementById('btn-apply-paste').disabled = false;
}

function applyParsedQuestions() {
    if (!parsedStages || parsedStages.length===0) return;
    document.getElementById('stages-container').innerHTML = '';
    stageCount = 0; questionIdCounter = 0;
    parsedStages.forEach((stage, idx) => {
        stageCount++; const stageId = stageCount;
        const container = document.getElementById('stages-container');
        const card = document.createElement('div');
        card.className = 'stage-card'; card.id = `stage-${stageId}`;
        card.innerHTML = `<div class="stage-card-header"><h4>🏁 스테이지 ${idx+1}: ${escapeHtml(stage.title)}</h4><button class="btn-remove-stage" onclick="removeStage(${stageId})">✕</button></div><div id="questions-${stageId}" class="questions-list"></div><button class="btn-add-question" onclick="addQuestion(${stageId})">+ 문제 추가</button>`;
        container.appendChild(card);
        stage.questions.forEach(q => fillQuestion(stageId, { type:'short', text: q.text, answers: q.answer ? [q.answer] : [] }));
    });
    closePasteModal();
    showToast(`✅ ${parsedStages.length}개 스테이지 입력 완료!`);
}
