// ===== student.js - 학생 게임 참여 로직 (Firebase) =====

let myPlayerId = null;
let myGameCode = null;
let myCurrentStage = 1;
let myWrongCount = 0;
let selectedChoice = -1;
let selectedTeam = null;
let studentTimerInterval = null;
let currentGameData = null;

async function joinGame() {
    const code = document.getElementById('join-code').value.trim().toUpperCase();
    const name = document.getElementById('join-name').value.trim();
    if (!code || code.length < 4) { showToast('게임 코드를 입력해주세요'); return; }
    if (!name) { showToast('이름을 입력해주세요'); return; }

    const game = await getGameAsync(code);
    if (!game) { showToast('존재하지 않는 게임 코드입니다'); return; }
    if (game.status === 'finished') { showToast('이미 종료된 게임입니다'); return; }

    if (game.teamMode) {
        if (!selectedTeam) {
            document.getElementById('team-select-area').classList.remove('hidden');
            showToast('팀을 선택해주세요');
            return;
        }
    }

    myGameCode = code;
    myPlayerId = 'p_' + Date.now() + '_' + Math.random().toString(36).substr(2,4);
    myCurrentStage = 1;
    myWrongCount = 0;

    const playerData = {
        name, team: selectedTeam || '', currentStage: 1,
        wrongCount: 0, joinedAt: Date.now(), clearedAt: null
    };
    updatePlayerData(code, myPlayerId, playerData);

    document.getElementById('waiting-name').textContent = name;
    document.getElementById('waiting-team').textContent = selectedTeam ? `${selectedTeam === 'A' ? '🔴 A팀' : '🔵 B팀'}` : '';
    showPage('page-student-waiting');

    // Listen for game state changes
    listenGame(code, (game) => {
        currentGameData = game;
        if (game.status === 'playing') {
            showPage('page-student-game');
            startStudentGame(game);
        } else if (game.status === 'finished') {
            showStudentComplete(game);
        }
    });
}

function selectTeam(team) {
    selectedTeam = team;
    document.querySelectorAll('.btn-team').forEach(b => b.classList.remove('selected'));
    document.querySelector(`.btn-team-${team.toLowerCase()}`).classList.add('selected');
}

let gameStarted = false;
function startStudentGame(game) {
    if (gameStarted) return;
    gameStarted = true;
    currentGameData = game;
    const totalStages = game.stages.length;
    document.getElementById('stage-total-label').textContent = `/ ${totalStages}`;
    buildStageMap(totalStages);
    loadStageQuestion(game);
    startStudentTimer(game);
}

function buildStageMap(total) {
    const map = document.getElementById('stage-map');
    map.innerHTML = '';
    for (let i = 1; i <= total; i++) {
        if (i > 1) {
            const conn = document.createElement('div');
            conn.className = 'stage-connector' + (i < myCurrentStage ? ' cleared' : '');
            conn.id = `conn-${i}`;
            map.appendChild(conn);
        }
        const node = document.createElement('div');
        node.className = 'stage-node' + (i === myCurrentStage ? ' active' : i < myCurrentStage ? ' cleared' : '');
        node.id = `node-${i}`;
        node.textContent = i;
        map.appendChild(node);
    }
}

function updateStageMap() {
    if (!currentGameData) return;
    const total = currentGameData.stages.length;
    for (let i = 1; i <= total; i++) {
        const node = document.getElementById(`node-${i}`);
        if (!node) continue;
        node.className = 'stage-node' + (i === myCurrentStage ? ' active' : i < myCurrentStage ? ' cleared' : '');
        if (i > 1) {
            const conn = document.getElementById(`conn-${i}`);
            if (conn) conn.className = 'stage-connector' + (i <= myCurrentStage ? ' cleared' : '');
        }
    }
}

function loadStageQuestion(game) {
    if (!game) game = currentGameData;
    if (!game) return;
    const total = game.stages.length;
    if (myCurrentStage > total) { showStudentComplete(game); return; }

    document.getElementById('current-stage-label').textContent = `스테이지 ${myCurrentStage}`;
    const stageQuestions = game.stages[myCurrentStage - 1];
    const q = stageQuestions[Math.floor(Math.random() * stageQuestions.length)];

    document.getElementById('q-text').textContent = q.text;
    selectedChoice = -1;

    if (q.type === 'multiple') {
        document.getElementById('q-type-badge').textContent = '객관식';
        document.getElementById('choices-area').classList.remove('hidden');
        document.getElementById('short-answer-area').classList.add('hidden');
        const btns = document.querySelectorAll('.choice-btn');
        btns.forEach((btn, i) => {
            btn.textContent = q.choices[i];
            btn.className = 'choice-btn';
            btn.disabled = false;
        });
        window._currentQ = q;
    } else {
        document.getElementById('q-type-badge').textContent = '주관식';
        document.getElementById('choices-area').classList.add('hidden');
        document.getElementById('short-answer-area').classList.remove('hidden');
        document.getElementById('short-answer-input').value = '';
        document.getElementById('short-answer-input').focus();
        window._currentQ = q;
    }
    document.getElementById('btn-submit-answer').disabled = false;
}

function selectChoice(idx) {
    selectedChoice = idx;
    document.querySelectorAll('.choice-btn').forEach((b, i) => {
        b.className = 'choice-btn' + (i === idx ? ' selected' : '');
    });
}

function submitAnswer() {
    const q = window._currentQ;
    if (!q) return;
    let correct = false;

    if (q.type === 'multiple') {
        if (selectedChoice === -1) { showToast('답을 선택해주세요'); return; }
        correct = selectedChoice === q.answer;
    } else {
        const input = document.getElementById('short-answer-input').value.trim().toLowerCase();
        if (!input) { showToast('답을 입력해주세요'); return; }
        correct = q.answers.some(a => a === input || a.replace(/\s/g,'') === input.replace(/\s/g,''));
    }

    document.getElementById('btn-submit-answer').disabled = true;
    showFeedback(correct);
}

function showFeedback(correct) {
    const overlay = document.getElementById('feedback-overlay');
    const content = document.getElementById('feedback-content');
    overlay.classList.remove('hidden');

    if (correct) {
        content.className = 'feedback-content fb-correct';
        content.innerHTML = '<div class="fb-icon">🎉</div><div class="fb-text">정답!</div><div class="fb-sub">다음 스테이지로!</div>';
        myCurrentStage++;
        updatePlayerData(myGameCode, myPlayerId, { currentStage: myCurrentStage });
        setTimeout(() => {
            overlay.classList.add('hidden');
            updateStageMap();
            if (currentGameData) loadStageQuestion(currentGameData);
        }, 1500);
    } else {
        myWrongCount++;
        content.className = 'feedback-content fb-wrong';
        if (myCurrentStage > 1) {
            myCurrentStage = Math.max(1, myCurrentStage - 1);
            content.innerHTML = '<div class="fb-icon">😢</div><div class="fb-text">오답!</div><div class="fb-sub">1단계 뒤로...</div>';
        } else {
            content.innerHTML = '<div class="fb-icon">😢</div><div class="fb-text">오답!</div><div class="fb-sub">다시 도전!</div>';
        }
        updatePlayerData(myGameCode, myPlayerId, { currentStage: myCurrentStage, wrongCount: myWrongCount });
        setTimeout(() => {
            overlay.classList.add('hidden');
            updateStageMap();
            if (currentGameData) loadStageQuestion(currentGameData);
        }, 1500);
    }
}

function startStudentTimer(game) {
    if (studentTimerInterval) clearInterval(studentTimerInterval);
    const timerEl = document.getElementById('student-timer');
    studentTimerInterval = setInterval(() => {
        if (!game.startedAt) return;
        const remaining = Math.max(0, game.timer - Math.floor((Date.now() - game.startedAt) / 1000));
        const m = Math.floor(remaining / 60), s = remaining % 60;
        timerEl.textContent = `${String(m).padStart(2,'0')}:${String(s).padStart(2,'0')}`;
        timerEl.className = 'game-timer' + (remaining < 30 ? ' danger' : remaining < 60 ? ' warning' : '');
        if (remaining <= 0) { clearInterval(studentTimerInterval); showStudentComplete(game); }
    }, 1000);
}

function showStudentComplete(game) {
    if (studentTimerInterval) clearInterval(studentTimerInterval);
    showPage('page-student-complete');
    const total = game ? game.stages.length : 0;
    const cleared = myCurrentStage > total;
    const el = document.getElementById('complete-content');
    if (cleared) {
        updatePlayerData(myGameCode, myPlayerId, { clearedAt: Date.now() });
        el.innerHTML = `<div class="trophy">🏆</div><h2>축하합니다!</h2><p class="clear-time">모든 스테이지 클리어!</p><p class="clear-stats">오답 수: ${myWrongCount}</p>`;
    } else {
        el.innerHTML = `<div class="trophy">⏰</div><h2>시간 종료!</h2><p class="clear-time">스테이지 ${myCurrentStage-1}/${total} 도달</p><p class="clear-stats">오답 수: ${myWrongCount}</p>`;
    }
}
